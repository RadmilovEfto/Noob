#Vezba 3

# Ako je tajni pin 4231 ILI ako je tajni pin 3124 ispisi poruku " Pin je Tachan"
# U suprotnom izbaciti poruku "Netachan pin"
#Zabranjeno koriscenje vise od 1 IF-a i zabranjeno korischenje elif
# Dozvoljeno 1 if + 1 else :D

tajni_pin = 4231

if tajni_pin == 4231 or tajni_pin == 3124 :
    print("PIN JE TACHAN")
else :
    print("NETACHAN PIN")
